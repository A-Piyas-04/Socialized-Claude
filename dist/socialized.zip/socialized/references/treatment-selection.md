# Choosing and balancing operations

How to decide which operations to use when they pull in different directions,
how to spend a limited length budget, and which failure modes the rules in
`SKILL.md` exist to prevent.

## Contents

1. Selection defaults
2. Resolving conflicts
3. The length budget
4. Failure modes to avoid

## 1. Selection defaults

Start from "use nothing" and add an operation only when you can name the
specific gap it fills for this reader.

- **Ordering by dependency** fits whenever the answer has more than one idea
  and the reader may lack one of the earlier ones. If the natural order already
  works, leaving it alone is correct.
- **Mechanism** fits when the question is why or how, or when the reader's
  confusion is about cause. It is unnecessary when the user wants a fact, a
  definition, or a procedure to follow.
- **One running example** fits when the idea is abstract and the reader is not an
  expert, when they ask for one, or when a concrete case would expose a likely
  misconception. Reuse that same case where a later idea needs a concrete case,
  tracing initial state, action, and resulting state, and let it add only what a
  figure has not already shown.
- **Defining a term** fits when the term is load-bearing and this reader
  probably doesn't know it.
- **Plain sentences** fit every explanation. They change how each sentence is
  built, not what it says, and they cost no extra words.
- **Presentation** fits every answer with more than one idea. Pick the form from
  the content's shape: steps for a process, a table for three or more items on
  shared dimensions, a diagram for a flow, an interaction, or how components
  connect, prose for a single causal chain. Leave a blank line between units,
  and end a paragraph by four sentences as a ceiling, not a target. A two-sentence
  answer gets two sentences and nothing else.
- **A visual** fits an idea whose content has a shape that would take three or
  more sentences to describe, and it replaces those sentences. There is no quota and
  no cap; the cost stays flat because each figure deletes its prose, so draw as many
  as the ideas earn and leave one out where the prose already makes the relationship
  plain. Prefer one representation per mechanism, and add another whenever it shows
  something the first cannot. Spend the first one on the hardest idea, and give a
  later idea its own when it is just as hard. Give every figure, table and paragraph
  a different job: the figure shows what happens and in what order, a table compares
  or tracks state, and the text says why. Pick sequence diagrams for order in time,
  flowcharts for branches, architecture diagrams for components and connections,
  state tables for change over time, and a compact arrow chain for a short linear
  flow. Render it as markdown. Build an artifact only when the person explicitly
  asks for one.
- **Semantic icons** fit a substantive explanation or technical discussion by
  default: a meaning-matched icon may label a heading, node or component, each one
  marking a different kind of part (🧠 concept, ⚙️ mechanism, 📡 signalling, 🗄️
  storage, 🔄 state transition, 📊 comparison, 💡 insight, 🛡️ security). They
  stay out of code, formal writing, and short or casual replies.
- **A takeaway** fits a long or multi-section teaching answer whose last sentence
  does not already land the point. A check question, with its answer, fits only
  when the person asks to practise or be tested, the exchange is a tutorial, or
  one question resolves a real uncertainty. A quick, practitioner, or expert
  answer ends when the content ends.

## 2. Resolving conflicts

- **Directness beats strict ordering for specific questions.** If the user asked
  a specific question, answer it first. Then supply the one prerequisite that
  makes the answer make sense. The answer comes before any background.
- **The user's stated length beats everything.** "Briefly" means keep the single
  most important point and drop the rest.
- **Expertise beats scaffolding.** For a reader who evidently knows the field,
  skip background and give the precise answer at their level. Scaffolding that
  helps a newcomer slows an expert down.
- **Accuracy beats simplicity.** If the simple version would be wrong in a way
  that matters, give the accurate version with a short nuance.
- **An example beats an analogy** when both would work. A direct case from the
  domain cannot mislead about the domain the way an analogy can.

## 3. The length budget

When something has to go, keep content in this order of priority, from highest
to lowest:

- The direct answer to the question asked.
- A caveat without which the answer would mislead.
- A missing prerequisite this reader needs.
- A missing causal step.
- The tradeoff or limit that follows from the mechanism.
- The form that shows the content's shape (steps, table rows, headings).
- An example.
- Visuals that replaced prose. When one must go, cut the visual on the easiest
  idea and keep the one on the hardest.
- The takeaway sentence. Cut the check question before the takeaway.
- A figure, example, walkthrough or recap that repeats what another part already
  shows. Cut it first.

Cut from the bottom. An answer that has to be scrolled should earn every
paragraph.
Presentation costs few words, so it is cut last, not first: when shortening,
drop sentences and keep the steps, rows, and headings that show the shape.

## 4. Failure modes to avoid

Earlier rewriting experiments that applied each operation unconditionally
produced these failures. The rules in `SKILL.md` exist to prevent them.

- **Naming prerequisites instead of teaching them.** "To understand this, we
  first rely on the client-server model, packets, and reliable delivery" lists
  three ideas and teaches none of them.
- **Signposting.** "Now that these foundations are in place…", "With the
  structure established, we can examine…". These add length and no
  understanding. Let the order speak for itself.
- **Inventing dependencies.** Saying two ideas are "mutually dependent", or that
  one is "defined by" another, when they are not. Only state a dependency that
  is real.
- **Certainty creep.** Adding a cause and, along the way, turning "can lose data"
  into "will lose data" or adding "never" and "guaranteed". Keep the original
  strength of every claim.
- **Dropped hedges.** Expanding an explanation and losing the "usually", "can",
  or "in most cases" that made it true.
- **Causal padding.** Putting "because" or "as a result" in every sentence, or
  expanding steps the reader already understands. In one experiment this added
  about 40% to typical length, with no measured gain in understanding.
- **Unsupported elaboration.** Adding mechanism details that sound right but go
  beyond what is actually established, or meta-commentary about what "the
  source" does not say.
- **Examples that read as facts.** Specific numbers, addresses, or company
  behaviour invented to make an example concrete, without marking them as
  illustrative.
- **Examples that break the mechanism.** An example whose details contradict the
  rule being explained. Check the example against every rule you state.
- **Decorative structure.** Headings over one-sentence sections, bullets that
  chop one continuous argument into fragments, a table with one meaningful
  column, or bolding so frequent that nothing stands out.
- **Decorative icons.** An icon on every bullet or sentence, the same icon on
  different kinds of part, an emoji inside code, JSON or a formal document, or a
  status marker standing alone in its list.
- **Whitespace padding.** Every sentence its own paragraph when the sentences
  form one continuous argument. A unit break marks an idea break, not a line
  break.
- **Empty transitional units.** A paragraph or heading whose only content is
  announcing what comes next.
- **A wall of text.** A paragraph that carries two independently important ideas
  or blurs cause, mechanism and consequence, often in the back half after a
  well-spaced first screen. Split it and leave the blank line.
- **A congested table.** An argument in a cell (a condition, a second reason, an
  exception), more than four columns, or a header that names nothing. A short
  sentence in a cell is fine. Keep the verdict in the cell and move the reasoning
  to a list under the table.
- **A bold line for a heading.** A bold phrase on its own line that announces a
  section. Use `##` or `###`.
- **A specimen left inline.** Sample data, a snippet, or an output folded into a
  sentence. Lift it into a titled fenced block.
- **Depth with no layer.** Specialist detail interleaved with the core thread,
  or core, supporting and optional claims sharing one paragraph. Establish the
  essential concept and its mechanism first; put variants, tuning and one system's
  edge cases in a **Deeper:** block the reader can skip.
- **Identifiers at body weight.** A path, flag, or product name in plain text
  mid-sentence. Put it in backticks.
- **The same mechanism told twice.** A figure that restates a shape the prose
  already made obvious; the sentences the figure replaced left in place; numbered
  steps that walk its arrows; a second figure, an example or a recap that shows
  the same transitions again. Give each its own job: the figure what happens, the
  text why and what would break. A second figure stays when it shows something the
  first cannot, and a walkthrough when this reader needs the steps in words.
- **An elaborate figure that is wrong.** A transition with the wrong trigger
  (a read drawn where only a write causes it), or an arrow the mechanism does not
  have. A smaller figure that is right teaches more.
- **An uncaptioned figure.** A diagram, table, or bar block with no sentence
  saying what it shows and what to notice.
- **An unrequested artifact.** An HTML, SVG, or interactive file when the
  person did not explicitly ask for an artifact, an SVG, or something to click.
  "Explain this visually" is a request for the markdown form.
- **A figure whose parts all look alike.** Identical boxes with nothing marking
  the key node, the peers, or a different kind of thing.
- **Structure without time.** A box-and-arrow map of a process whose point is
  order or waiting. Use a `sequenceDiagram`.
- **Colour used once.** One coloured element, so nothing else in the answer is
  encoded. Name one code and reuse it in every figure.
- **Quantities left in sentences.** Ratios and ranges stated as numbers when
  their scale is the point. Draw the bars.
- **A quiz on a quick answer.** A check question after a fact, a lookup, or an
  expert reply. Those end when the content ends.
- **A question nobody can check.** An open prompt with no options and no answer.
  Give three options or a short factual answer, then the answer itself.
- **A recap instead of a compression.** A closing paragraph that restates the
  body. The takeaway is an arrow chain or one line of 25 words or fewer.
- **One system taught as the rule.** One product's internals (a database's log
  format, a broker's acknowledgement mode) presented as how the whole category
  works. Teach the general mechanism, then label that system's version.
- **Qualifiers on every sentence.** The same assumption or setting restated as a
  clause in each sentence, until the mechanism is hard to follow. State it once,
  where it first matters.
- **Over-expansion.** Every operation applied to every answer. The goal is an
  answer that is easier to understand, not one that is longer.
