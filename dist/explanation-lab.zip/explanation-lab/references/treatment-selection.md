# Choosing and balancing operations

How to decide which operations to use when they pull in different directions,
how to spend a limited length budget, and which failure modes the rules in
`SKILL.md` exist to prevent.

## Contents

1. Selection defaults
2. Resolving conflicts
3. The length budget
4. Failure modes to avoid

## 1. Selection defaults

Start from "use nothing" and add an operation only when you can name the
specific gap it fills for this reader.

- **Ordering by dependency** fits whenever the answer has more than one idea
  and the reader may lack one of the earlier ones. If the natural order already
  works, leaving it alone is correct.
- **Mechanism** fits when the question is why or how, or when the reader's
  confusion is about cause. It is unnecessary when the user wants a fact, a
  definition, or a procedure to follow.
- **One example** fits when the idea is abstract and the reader is not an
  expert, when they ask for one, or when a concrete case would expose a likely
  misconception.
- **Defining a term** fits when the term is load-bearing and this reader
  probably doesn't know it.
- **Plain sentences** fit every explanation. They change how each sentence is
  built, not what it says, and they cost no extra words.
- **Presentation** fits every answer with more than one idea. Pick the form from
  the content's shape: steps for a process, a table for three or more items on
  shared dimensions, a fenced diagram for a branching flow, prose for a single
  causal chain. A two-sentence answer gets two sentences and nothing else.

## 2. Resolving conflicts

- **Directness beats strict ordering for specific questions.** If the user asked
  a specific question, answer it first. Then supply the one prerequisite that
  makes the answer make sense. The answer comes before any background.
- **The user's stated length beats everything.** "Briefly" means keep the single
  most important point and drop the rest.
- **Expertise beats scaffolding.** For a reader who evidently knows the field,
  skip background and give the precise answer at their level. Scaffolding that
  helps a newcomer slows an expert down.
- **Accuracy beats simplicity.** If the simple version would be wrong in a way
  that matters, give the accurate version with a short nuance.
- **An example beats an analogy** when both would work. A direct case from the
  domain cannot mislead about the domain the way an analogy can.

## 3. The length budget

When something has to go, keep content in this order of priority, from highest
to lowest:

- The direct answer to the question asked.
- A caveat without which the answer would mislead.
- A missing prerequisite this reader needs.
- A missing causal step.
- The tradeoff or limit that follows from the mechanism.
- The form that shows the content's shape (steps, table rows, diagram).
- An example.

Cut from the bottom. An answer that has to be scrolled should earn every
paragraph.
Presentation costs few words, so it is cut last, not first: when shortening,
drop sentences and keep the steps, rows, and headings that show the shape.

## 4. Failure modes to avoid

Earlier rewriting experiments that applied each operation unconditionally
produced these failures. The rules in `SKILL.md` exist to prevent them.

- **Naming prerequisites instead of teaching them.** "To understand this, we
  first rely on the client-server model, packets, and reliable delivery" lists
  three ideas and teaches none of them.
- **Signposting.** "Now that these foundations are in place…", "With the
  structure established, we can examine…". These add length and no
  understanding. Let the order speak for itself.
- **Inventing dependencies.** Saying two ideas are "mutually dependent", or that
  one is "defined by" another, when they are not. Only state a dependency that
  is real.
- **Certainty creep.** Adding a cause and, along the way, turning "can lose data"
  into "will lose data" or adding "never" and "guaranteed". Keep the original
  strength of every claim.
- **Dropped hedges.** Expanding an explanation and losing the "usually", "can",
  or "in most cases" that made it true.
- **Causal padding.** Putting "because" or "as a result" in every sentence, or
  expanding steps the reader already understands. In one experiment this added
  about 40% to typical length, with no measured gain in understanding.
- **Unsupported elaboration.** Adding mechanism details that sound right but go
  beyond what is actually established, or meta-commentary about what "the
  source" does not say.
- **Examples that read as facts.** Specific numbers, addresses, or company
  behaviour invented to make an example concrete, without marking them as
  illustrative.
- **Examples that break the mechanism.** An example whose details contradict the
  rule being explained. Check the example against every rule you state.
- **Decorative structure.** Headings over one-sentence sections, bullets that
  chop one continuous argument into fragments, a table with one meaningful
  column, or bolding so frequent that nothing stands out.
- **Emoji as structure.** Emoji used as bullet markers, section icons, or status
  indicators.
- **Whitespace padding.** Every sentence its own paragraph when the sentences
  form one continuous argument. A unit break marks an idea break, not a line
  break.
- **Empty transitional units.** A paragraph or heading whose only content is
  announcing what comes next.
- **Over-expansion.** Every operation applied to every answer. The goal is an
  answer that is easier to understand, not one that is longer.
